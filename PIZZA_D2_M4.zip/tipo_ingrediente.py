class TipoIngrediente:
    #ATRIBUTOS DE CLASE PARA INGREDIENTES Y TIPO DE MASA
    ingredientes_proteicos = ["pollo", "vacuno", "carne vegetal"]
    ingredientes_vegetales = ["tomate", "aceitunas", "champiñones"]
    tipo_de_masa = ["tradicional", "delgada"]


